public interface IHealable
{
    void Heal(float amount);
}