using System.Collections.Generic;
using UnityEngine;

public class StatusReceiver2D : MonoBehaviour
{
    // �C�Ӫ��A�@�� runtime instance
    class RuntimeStatus
    {
        public StatusEffectData data;
        public float endTime;          // Time.time + duration�Fduration=0 �ɥi����
        public int stacks = 1;

        // DOT
        public float nextTickTime;

        // Slow�G�ثe�M�Ϊ����v�]���̤j/�̤p�W�h�Ρ^
        public float magnitude;
    }

    [Header("Target")]
    [Tooltip("�� PlayerStatTarget2D / EnemyStatTarget2D�]Unity ����ǦC�� interface�A�ҥH�� MonoBehaviour �૬�^")]
    [SerializeField] MonoBehaviour targetBehaviour;

    IStatTarget2D target; // PlayerStatTarget2D / EnemyStatTarget2D

    readonly Dictionary<string, RuntimeStatus> active = new Dictionary<string, RuntimeStatus>();

    void Awake()
    {
        // ���ΧA��ʩ쪺�]���ˡ^
        if (targetBehaviour != null)
            target = targetBehaviour as IStatTarget2D;

        // �S��N�۰ʧ�
        if (target == null)
        {
            target = GetComponent<IStatTarget2D>();
            targetBehaviour = target as MonoBehaviour; // ��K�A����b Inspector �ݨ�
        }

        if (target == null)
            Debug.LogError($"[StatusReceiver2D] No IStatTarget2D found on {name}", this);
    }
    // ========================
    // Apply
    // ========================
    public void Apply(StatusEffectData data, GameObject instigator = null)
    {
        if (data == null) return;
        if (target == null) return;

        if (!active.TryGetValue(data.id, out var rs))
        {
            rs = new RuntimeStatus { data = data };
            active.Add(data.id, rs);

            // �즸�M�ΡG�i�� enter �欰
            OnEnter(rs);
        }

        // �|�[�W�h
        switch (data.stackRule)
        {
            case StatusStackRule.RefreshDuration:
                rs.stacks = 1;
                break;

            case StatusStackRule.StackAdd:
                rs.stacks = Mathf.Min(rs.stacks + 1, data.maxStacks);
                break;

            case StatusStackRule.TakeMaxMagnitude:
                // �o�W�h�q�`�Φb Slow�G���u��C�v= ����p multiplier
                rs.magnitude = Mathf.Min(rs.magnitude, GetMagnitude(data));
                break;
        }

        // ��s�ɶ��]duration=0 ���ܥä[�^
        if (data.duration > 0f)
            rs.endTime = Time.time + data.duration;

        // DOT �ߧY���\ tick�]���@�w�n�ߨ覩�A�i�ۦ�令 Time.time + tickInterval�^
        if (data.kind == StatusKind.PoisonDot)
            rs.nextTickTime = Mathf.Min(rs.nextTickTime, Time.time);

        // �s�W�GHeal �ߧY���\ tick�]�Ҧ��P DOT�^
        if (data.kind == StatusKind.Heal)
            rs.nextTickTime = Mathf.Min(rs.nextTickTime, Time.time);

        // ��s���򫬮ĪG�]�p Slow ���̤j�^
        OnRefresh(rs);
    }



    public void Remove(StatusEffectData data)
    {
        if (data == null) return;
        if (!active.TryGetValue(data.id, out var rs)) return;

        OnExit(rs);
        active.Remove(data.id);
    }

    // ========================
    // Update
    // ========================
    void Update()
    {
        if (active.Count == 0) return;

        float now = Time.time;

        // Snapshot keys�]�קK���N���������^
        var keys = ListPool<string>.Get();
        keys.AddRange(active.Keys);

        for (int i = 0; i < keys.Count; i++)
        {
            var id = keys[i];
            if (!active.TryGetValue(id, out var rs)) continue;

            // �������
            if (rs.data.duration > 0f && now >= rs.endTime)
            {
                OnExit(rs);
                active.Remove(id);
                continue;
            }

            // ����欰�]DOT�^
            if (rs.data.kind == StatusKind.PoisonDot)
                confirmsPoison(rs, now);

            // �s�W�G����欰�]Heal�^
            if (rs.data.kind == StatusKind.Heal)
                confirmsHeal(rs, now);
        }

        ListPool<string>.Release(keys);
    }



    void confirmsPoison(RuntimeStatus rs, float now)
    {
        var data = rs.data;

        if (now < rs.nextTickTime) return;

        float dmgPerTick = data.dps * data.tickInterval * rs.stacks;
        target.DealDamage(dmgPerTick, transform.position, gameObject);

        rs.nextTickTime = now + data.tickInterval;
    }
    // ========================
    //�s�W�GHeal Tick�]���c������� Poison�^
    // ========================
    void confirmsHeal(RuntimeStatus rs, float now)
    {
        var data = rs.data;

        if (now < rs.nextTickTime) return;

        float healPerTick = data.healPerTick * rs.stacks;
        target.Heal(healPerTick);

        rs.nextTickTime = now + data.tickInterval;
    }



    void OnEnter(RuntimeStatus rs)
    {
        // �]�w��l�j��
        rs.magnitude = GetMagnitude(rs.data);

        // Slow �@�i�ӴN�M��
        if (rs.data.kind == StatusKind.Slow)
            target.SetMoveSpeedMultiplier(rs, rs.magnitude);
    }

    void OnRefresh(RuntimeStatus rs)
    {
        // Slow�G�̳W�h�վ㭿�v
        if (rs.data.kind == StatusKind.Slow)
        {
            float mag = (rs.data.stackRule == StatusStackRule.TakeMaxMagnitude)
                ? rs.magnitude
                : GetMagnitude(rs.data);

            target.SetMoveSpeedMultiplier(rs, mag);
        }
    }

    void OnExit(RuntimeStatus rs)
    {
        if (rs.data.kind == StatusKind.Slow)
            target.ClearMoveSpeedMultiplier(rs);
    }

    float GetMagnitude(StatusEffectData data)
    {
        if (data.kind == StatusKind.Slow) return Mathf.Clamp01(data.slowMultiplier);
        return 1f;
    }

    // --- tiny pool ---
    static class ListPool<T>
    {
        static readonly Stack<List<T>> pool = new Stack<List<T>>();
        public static List<T> Get() => pool.Count > 0 ? pool.Pop() : new List<T>(16);
        public static void Release(List<T> list) { list.Clear(); pool.Push(list); }
    }
}
