﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class StartMenuUI : MonoBehaviour
{
    [Header("UI Panels")]
    public GameObject startPanel;

    [Header("References")]
    public CreditUI creditUI;       // 保留原本變數
    public GameObject hudPanel;     // 保留原本變數

    void Start()
    {
        if (GameManager.IsLoadingNextLevel)
        {
            // === 正在載入下一關 ===
            if (startPanel != null) startPanel.SetActive(false);
            Time.timeScale = 1f;
            GameManager.IsLoadingNextLevel = false;
        }
        else
        {
            // === 剛進遊戲 / 回主選單 ===
            if (startPanel != null) startPanel.SetActive(true);
            Time.timeScale = 0f;

            if (AudioManager_2D.Instance != null)
            {
                // 1. 播主選單音樂
                AudioManager_2D.Instance.PlayUIBGM(UIBGMType.Start);

                // 2. ★★★ 參考 GameOverUI 邏輯：明確停止遊戲音樂 ★★★
                // 這樣從戰鬥中退出時，戰鬥音樂就會立刻閉嘴
                AudioManager_2D.Instance.StopGameplayBGM();
            }
        }
    }

    // 當按下 Start 按鈕
    public void OnStartGame()
    {
        Time.timeScale = 1f;
        startPanel.SetActive(false);

        if (AudioManager_2D.Instance != null)
        {
            // 1. 播關卡音樂
            AudioManager_2D.Instance.PlayBGMByLevelIndex(GameManager.CurrentMapIndex);

            // 2. ★★★ 新增：明確停止選單音樂 ★★★
            // 避免進遊戲後，選單音樂還在背景響
            AudioManager_2D.Instance.StopUIBGM();
        }
    }

    public void OnExitGame()
    {
        Debug.Log("Exit Game");
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
    public void OnCreditsClicked()
    {
        // 1. 隱藏主選單
        if (startPanel != null) startPanel.SetActive(false);

        // 2. 顯示 Credit 介面
        if (creditUI != null)
        {
            creditUI.Show();
        }
        else
        {
            Debug.LogError("CreditUI 沒拉！請檢查 StartMenuUI 的 Inspector");
        }
    }

    // 給 CreditUI 的「Back 按鈕」呼叫 (當從 Credit 返回時)
    public void ShowMainPanel()
    {
        if (startPanel != null) startPanel.SetActive(true);
    }
}

