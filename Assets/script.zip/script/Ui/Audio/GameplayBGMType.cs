public enum GameplayBGMType
{
    None,
    Normal_A,
    Normal_B,
    Boss_5,
    Boss_10
}
