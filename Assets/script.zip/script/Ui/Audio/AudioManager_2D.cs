﻿using System.Collections.Generic;
using UnityEngine;

public class AudioManager_2D : MonoBehaviour
{
    public static AudioManager_2D Instance;

    [Header("Audio Sources")]
    public AudioSource uiBGMSource;
    public AudioSource gameplayBGMSource;
    public AudioSource uiSFXSource;
    public AudioSource gameplaySFXSource;

    [Header("UI BGM Clips")]
    public AudioClip startUIBGM;
    public AudioClip gameOverUIBGM;

    [Header("Gameplay BGM Clips")]
    public AudioClip normalA_BGM;
    public AudioClip normalB_BGM;
    public AudioClip boss5_BGM;
    public AudioClip boss10_BGM;

    [Header("UI SFX Clips")]
    public AudioClip hoverClip;
    public AudioClip clickClip;

    [Header("SFX Optimization")]
    [Tooltip("least time between same sfx")]
    public float sfxCooldown = 0.1f;

    private Dictionary<AudioClip, float> sfxLastPlayTimes = new Dictionary<AudioClip, float>();

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    // ======================
    // UI BGM
    // ======================
    public void PlayUIBGM(UIBGMType type)
    {
        AudioClip target = null;

        if (type == UIBGMType.Start) target = startUIBGM;
        if (type == UIBGMType.GameOver) target = gameOverUIBGM;

        if (uiBGMSource.clip == target) return;

        uiBGMSource.Stop();
        uiBGMSource.clip = target;

        if (target != null)
        {
            uiBGMSource.loop = true;
            uiBGMSource.Play();
        }
    }

    public void StopUIBGM()
    {
        uiBGMSource.Stop();
        uiBGMSource.clip = null;
    }

    // ======================
    // Gameplay BGM（重點）
    // ======================
    public void PlayGameplayBGM(GameplayBGMType type)
    {
        AudioClip target = null;

        switch (type)
        {
            case GameplayBGMType.Normal_A:
                target = normalA_BGM;
                break;
            case GameplayBGMType.Normal_B:
                target = normalB_BGM;
                break;
            case GameplayBGMType.Boss_5:
                target = boss5_BGM;
                break;
            case GameplayBGMType.Boss_10:
                target = boss10_BGM;
                break;
        }

        if (target == null) return;
        if (gameplayBGMSource.clip == target) return;

        gameplayBGMSource.Stop();
        gameplayBGMSource.clip = target;
        gameplayBGMSource.loop = true;
        gameplayBGMSource.Play();
    }

    public void PauseGameplayBGM(bool pause)
    {
        if (pause) gameplayBGMSource.Pause();
        else gameplayBGMSource.UnPause();
    }

    // ======================
    // UI SFX
    // ======================
    public void PlayUIHover()
    {
        if (hoverClip)
            uiSFXSource.PlayOneShot(hoverClip);
    }

    public void PlayUIClick()
    {
        if (clickClip)
            uiSFXSource.PlayOneShot(clickClip);
    }

    public void PlayGameplayBGM_NormalA()
    {
        if (gameplayBGMSource.clip == normalA_BGM)
            return;

        gameplayBGMSource.Stop();
        gameplayBGMSource.clip = normalA_BGM;
        gameplayBGMSource.loop = true;
        gameplayBGMSource.Play();
    }

    public void PlayGameplaySFX(AudioClip clip)
    {
        // 1. 基本檢查
        if (clip == null || gameplaySFXSource == null) return;

        // 2. 檢查冷卻時間 (這是原本失效的地方)
        float lastTime;
        if (sfxLastPlayTimes.TryGetValue(clip, out lastTime))
        {
            // 如果現在時間距離上次播放還不到冷卻時間，直接 return，不要播放
            if (Time.time < lastTime + sfxCooldown)
            {
                return;
            }
        }

        // 刪除原本在這裡的第一個 gameplaySFXSource.PlayOneShot(clip); 
        // 你原本的代碼在這裡強制播放了一次，導致冷卻檢查無效。

        // 3. 通過檢查後，才播放音效
        gameplaySFXSource.PlayOneShot(clip);

        // 4. 更新最後播放時間
        sfxLastPlayTimes[clip] = Time.time;
    }

    // 在 AudioManager_2D 類別中
    public void PlayFootstep(AudioClip clip)
    {
        if (clip == null || gameplaySFXSource == null) return;

        // 隨機微調音高，讓腳步聲不單調
        gameplaySFXSource.pitch = Random.Range(0.9f, 1.1f);
        gameplaySFXSource.PlayOneShot(clip);
        gameplaySFXSource.pitch = 1.0f; // 播完後還原
    }

    public void StopGameplayBGM()
    {
        if (gameplayBGMSource != null)
        {
            gameplayBGMSource.Stop();
        }
    }

    // ★★★ 新增：自動根據關卡編號決定播哪首 BGM ★★★
    public void PlayBGMByLevelIndex(int mapIndex)
    {
        // mapIndex 是從 0 開始 (0, 1, 2...)
        // 我們習慣講第 1 關、第 2 關，所以 +1 比較好算
        int levelNum = mapIndex + 1;

        AudioClip targetClip = null;

        // --- 規則判斷區 ---

        // 規則 1: 第 5 關 -> Boss 1
        if (levelNum == 5)
        {
            targetClip = boss5_BGM;
        }
        // 規則 2: 第 10 關 -> Boss 2
        else if (levelNum == 10)
        {
            targetClip = boss10_BGM;
        }
        // 規則 3: 其他關卡 (奇數 A，偶數 B)
        else
        {
            // levelNum % 2 != 0 代表奇數 (1, 3, 7, 9...)
            if (levelNum % 2 != 0)
            {
                targetClip = normalA_BGM;
            }
            else
            {
                targetClip = normalB_BGM; // 偶數 (2, 4, 6, 8...)
            }
        }

        // --- 執行播放邏輯 ---

        // 如果沒歌或是已經在播同一首，就什麼都不做
        if (targetClip == null || gameplayBGMSource.clip == targetClip)
            return;

        gameplayBGMSource.Stop();
        gameplayBGMSource.clip = targetClip;
        gameplayBGMSource.loop = true;
        gameplayBGMSource.Play();
    }


}