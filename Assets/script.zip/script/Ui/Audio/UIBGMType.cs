public enum UIBGMType
{
    None,
    Start,
    GameOver
}