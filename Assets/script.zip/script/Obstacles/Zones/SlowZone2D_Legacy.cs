using System.Collections.Generic;
using UnityEngine;

public class SlowZone2D_Legacy : MonoBehaviour
{
    [Header("Slow")]
    [Tooltip("0.5 = 50% speed")]
    [Range(0.05f, 1f)]
    public float slowMultiplier = 0.5f;

    // �l�ܥثe�b�ϰ줺����H�]�קK���� Enter/Exit �X bug�^
    readonly HashSet<ISlowable2D> inside = new HashSet<ISlowable2D>();

    void OnTriggerEnter2D(Collider2D other)
    {
        var slowable = other.GetComponentInParent<ISlowable2D>();
        if (slowable == null) return;

        if (inside.Add(slowable))
        {
            slowable.SetSlowMultiplier(slowMultiplier);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        var slowable = other.GetComponentInParent<ISlowable2D>();
        if (slowable == null) return;

        if (inside.Remove(slowable))
        {
            slowable.ClearSlowMultiplier();
        }
    }

    void OnDisable()
    {
        // �p�G�K�����Q���z�BDisable/Destroy�A�T�O��H��_�t��
        foreach (var s in inside)
            s.ClearSlowMultiplier();

        inside.Clear();
    }
}
