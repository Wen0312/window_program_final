using System.Collections.Generic;
using UnityEngine;

public class PoisonZone2D_Legacy : MonoBehaviour
{
    [Header("Damage Over Time")]
    [Tooltip("Damage per second")]
    public float dps = 8f;

    [Tooltip("How often to apply damage (seconds). Smaller = smoother, bigger = cheaper.")]
    public float tickInterval = 0.25f;

    [Header("Targets")]
    public LayerMask affectMask; // Player / Enemy

    // �ؼ� -> �U�@�� tick ���ɶ�
    readonly Dictionary<IDamageable, float> nextTickTime = new Dictionary<IDamageable, float>();

    // ��C�G�קK�b Update �T�|�ɡA�Q OnTriggerEnter/Exit �ק� Dictionary
    readonly HashSet<IDamageable> pendingAdd = new HashSet<IDamageable>();
    readonly HashSet<IDamageable> pendingRemove = new HashSet<IDamageable>();

    void OnTriggerEnter2D(Collider2D other)
    {
        // Layer �L�o�]�קK�l�u/�����i�ӡ^
        if (((1 << other.gameObject.layer) & affectMask.value) == 0)
            return;

        var dmgable = other.GetComponentInParent<IDamageable>();
        if (dmgable == null) return;

        // �i�J�G���ƤJ��C�A�浹 Update �Τ@�B�z
        pendingAdd.Add(dmgable);
        pendingRemove.Remove(dmgable);
    }

    void OnTriggerExit2D(Collider2D other)
    {
        var dmgable = other.GetComponentInParent<IDamageable>();
        if (dmgable == null) return;

        // ���}�G���ƤJ��C�A�浹 Update �Τ@�B�z
        pendingRemove.Add(dmgable);
        pendingAdd.Remove(dmgable);
    }

    void Update()
    {
        // ���M�����}
        if (pendingRemove.Count > 0)
        {
            foreach (var d in pendingRemove)
                nextTickTime.Remove(d);
            pendingRemove.Clear();
        }

        // �A�M�ζi�J�]�즸�i�J�G���\�ߨ� tick�^
        if (pendingAdd.Count > 0)
        {
            foreach (var d in pendingAdd)
            {
                if (!nextTickTime.ContainsKey(d))
                    nextTickTime.Add(d, Time.time);
            }
            pendingAdd.Clear();
        }

        if (nextTickTime.Count == 0) return;

        float now = Time.time;
        float dmgPerTick = dps * tickInterval;

        //�� key snapshot�A�קK Dictionary �b�L�{���Q�ק�ɬ���
        var keys = ListPool<IDamageable>.Get();
        keys.AddRange(nextTickTime.Keys);

        var toRemove = ListPool<IDamageable>.Get();

        for (int i = 0; i < keys.Count; i++)
        {
            var dmgable = keys[i];

            // �ؼХi��w Destroy�]Unity null�^
            var mb = dmgable as MonoBehaviour;
            if (mb == null)
            {
                toRemove.Add(dmgable);
                continue;
            }

            // �i���n�Q�����]���}�r�ϡ^�A���L
            if (!nextTickTime.TryGetValue(dmgable, out float due))
                continue;

            if (now < due) continue;

            dmgable.TakeDamage(dmgPerTick, transform.position, gameObject);

            // ��s�U�@�� tick �ɶ�
            nextTickTime[dmgable] = now + tickInterval;
        }

        // �M�� Destroy ���ؼ�
        for (int i = 0; i < toRemove.Count; i++)
            nextTickTime.Remove(toRemove[i]);

        ListPool<IDamageable>.Release(keys);
        ListPool<IDamageable>.Release(toRemove);
    }

    void OnDisable()
    {
        nextTickTime.Clear();
        pendingAdd.Clear();
        pendingRemove.Clear();
    }

    // --- �W���q ListPool�]�קK�C�V new List �y�� GC�^ ---
    static class ListPool<T>
    {
        static readonly Stack<List<T>> pool = new Stack<List<T>>();

        public static List<T> Get()
        {
            return pool.Count > 0 ? pool.Pop() : new List<T>(16);
        }

        public static void Release(List<T> list)
        {
            list.Clear();
            pool.Push(list);
        }
    }
}
