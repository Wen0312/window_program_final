using UnityEngine;
using TMPro;

/// <summary>
/// WorldPromptUI2D
/// �̤p�i�Ϊ��u��ܤ@���r�vUI�]TMP �����^
/// - �u���� Show / Hide
/// - ���j�w���󤬰ʩΰʵe
/// </summary>
public class WorldPromptUI2D : MonoBehaviour
{
    [Header("Refs")]
    public Canvas canvas;
    public TMP_Text textUI;

    void Awake()
    {
        if (canvas == null)
            canvas = GetComponentInChildren<Canvas>(true);

        if (textUI == null)
            textUI = GetComponentInChildren<TMP_Text>(true);

        Hide();
    }

    public void Show(string msg)
    {
        if (canvas != null) canvas.enabled = true;
        if (textUI != null) textUI.text = msg;
    }

    public void Hide()
    {
        if (canvas != null) canvas.enabled = false;
    }
}
