public interface ISlowable2D
{
    // multiplier: 0.5 = �� 50% �t��
    void SetSlowMultiplier(float multiplier);
    void ClearSlowMultiplier();
}
