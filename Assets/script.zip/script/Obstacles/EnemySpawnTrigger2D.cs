using UnityEngine;

public class EnemySpawnTrigger2D : MonoBehaviour
{
    [Header("Spawn")]
    public GameObject enemyPrefab;
    public int spawnCount = 3;

    [Tooltip("Spawn within this radius around the trigger.")]
    public float spawnRadius = 1.5f;

    [Header("Proximity Trigger")]
    [Tooltip("Trigger when player is within this radius.")]
    public float triggerRadius = 4f;

    [Tooltip("How often we check distance (seconds). 0 = every frame.")]
    public float checkInterval = 0.1f;

    [Tooltip("Player tag.")]
    public string playerTag = "Player";

    [Header("Activation")]
    [Tooltip("How many times this trigger can activate (1 = one-shot).")]
    public int maxActivations = 1;

    [Tooltip("Seconds between activations (when maxActivations > 1).")]
    public float cooldown = 2f;

    [Header("Lifetime")]
    [Tooltip("Destroy this obstacle after reaching maxActivations.")]
    public bool destroyAfterDone = true;

    Transform playerTf;
    int activations = 0;
    float nextActivateTime = 0f;
    float nextCheckTime = 0f;

    void Awake()
    {
        // �۰ʧ쪱�a�]�ٱo�A��^
        var player = GameObject.FindGameObjectWithTag(playerTag);
        if (player != null) playerTf = player.transform;
    }

    void Update()
    {
        // 1) �}�o�̼Ҧ����ͮġ]�A�n���G�}�o��/�s���ɤ�Ĳ�o�^
        if (GameRuntimeFlags2D.developerProfile) return;

        // 2) �����ˬd
        if (maxActivations > 0 && activations >= maxActivations) return;

        // 3) �N�o
        if (Time.time < nextActivateTime) return;

        // 4) ���W�ˬd�Z���]�ٮį�^
        if (checkInterval > 0f && Time.time < nextCheckTime) return;
        nextCheckTime = Time.time + checkInterval;

        // 5) �䤣�쪱�a�N���խ���]���a�i�୫��/�����^
        if (playerTf == null)
        {
            var player = GameObject.FindGameObjectWithTag(playerTag);
            if (player != null) playerTf = player.transform;
            if (playerTf == null) return;
        }

        // 6) �Z���P�_�]�a��Ĳ�o�^
        float r = triggerRadius;
        float distSqr = (playerTf.position - transform.position).sqrMagnitude;
        if (distSqr > r * r) return;

        // Ĳ�o�ͦ�
        SpawnEnemies();

        activations++;
        nextActivateTime = Time.time + cooldown;

        // �Χ��۷��]ObstacleCore2D.OnDestroy �|�������^
        if (maxActivations > 0 && activations >= maxActivations && destroyAfterDone)
        {
            Destroy(gameObject);
        }
    }

    void SpawnEnemies()
    {
        if (enemyPrefab == null) return;

        for (int i = 0; i < spawnCount; i++)
        {
            Vector2 offset = Random.insideUnitCircle * spawnRadius;
            Vector3 pos = transform.position + (Vector3)offset;
            Instantiate(enemyPrefab, pos, Quaternion.identity);
        }
    }

    void OnDrawGizmosSelected()
    {
        // �s��ɥi���ơGĲ�o�b�| / �ͦ��b�|
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, triggerRadius);

        Gizmos.color = Color.magenta;
        Gizmos.DrawWireSphere(transform.position, spawnRadius);
    }
}
