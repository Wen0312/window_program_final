using UnityEngine;
using System;

public class PlayerHealth : MonoBehaviour, IDamageable
{
    public float maxHP = 10f;
    public float iFrameTime = 0.25f; // 

    public event Action<float, float> OnHPChanged; // current, max
    public event Action<float> OnDamaged;          // damage
    public event Action<float> OnHealed;           // �s�W�Gheal amount�]��ڸɨ�h�֡^
    public event Action OnDead;

    float hp;
    float invulUntil = 0f;

    void Awake()
    {
        hp = maxHP;
        OnHPChanged?.Invoke(hp, maxHP);
    }

    public void TakeDamage(float amount, Vector2 hitPoint, GameObject instigator)
    {
        if (Time.time < invulUntil) return;
        if (amount <= 0f) return;
        if (Time.time < invulUntil) return;

        invulUntil = Time.time + iFrameTime;

        hp -= amount;
        OnDamaged?.Invoke(amount);
        OnHPChanged?.Invoke(hp, maxHP);

        if (hp <= 0f)
        {
            hp = 0f;
            OnHPChanged?.Invoke(hp, maxHP);

            Debug.Log("Player Dead");
            OnDead?.Invoke();
        }
    }

    // �s�W�G�^��]���� iFrame�B��Ĳ�o OnDamaged�^
    public void Heal(float amount)
    {
        if (amount <= 0f) return;

        float before = hp;
        hp = Mathf.Min(maxHP, hp + amount);

        // �u���u���ɨ��~��s�]�קK����ɻ~�P�S�ĪG�^
        float healed = hp - before;
        if (healed > 0f)
        {
            OnHealed?.Invoke(healed);          // �s�W�G�� Feedback ��
            OnHPChanged?.Invoke(hp, maxHP);
        }
    }
}
