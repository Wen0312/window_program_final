using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerPlaceObstacle2D : MonoBehaviour
{
    [Header("Obstacle Data")]
    public ObstacleData[] obstacleList;     // 1~n �إi��m��
    public int currentIndex = 0;            // �ثe�����@��
    public ObstacleData currentObstacle;    // �ثe��ê���]�����޿�Ρ^

    [Header("Placement")]
    public LayerMask blockMask;             // Obstacle / Wall / Enemy / Player
    public Transform placeOrigin;           // optional

    [Header("Preview")]
    public bool previewEnabled = false;     // �� PlayerInputMode2D ����
    [Range(0.05f, 1f)]
    public float previewAlpha = 0.35f;      // Base sprite ���z����
    [Range(0.05f, 1f)]
    public float previewTintAlpha = 0.25f;  // ��/��B�n���z����
    public int previewSortingOrder = 1000;  // �T�O�b�̤W�h

    [Header("Rotation")]
    [Tooltip("Rotation in degrees (0 / 90 / 180 / 270)")]
    public int currentRotation = 0;

    [Header("Remove / Demolish")]
    [Tooltip("Seconds between removals to prevent spam-click.")]
    public float removeCooldown = 0.05f;

    // �@�ӹw������G���� + �B�n
    GameObject previewGO;

    // �o���令�G�����ƻs prefab �� Visual�]�]�t AutoFitSprite2D / localScale�^
    Transform previewBaseRoot;              // Base Visual root
    Transform previewTintRoot;              // Tint Visual root
    SpriteRenderer previewBaseSR;           // Base sprite renderer
    SpriteRenderer previewTintSR;           // Tint sprite renderer

    // cache�G�קK�C��������
    ObstacleData cachedData;
    GameObject cachedVisualSourceGO;        // prefab �̨��� SpriteRenderer �Ҧb�� GO�]�q�`�N�O Visual�^

    [Tooltip("Shared placement system (grid + occupancy).")]
    public PlacementSystem2D placementSystem;

    Camera cam;
    float nextPlaceTime;
    float nextRemoveTime;

    void Awake()
    {
        if (placementSystem == null) placementSystem = FindObjectOfType<PlacementSystem2D>();
        cam = Camera.main;
        if (placeOrigin == null) placeOrigin = transform;

        // ��l���
        SyncCurrentObstacle();

        // Create preview ghost (hidden by default)
        CreatePreviewGhost();
        SetPreviewActive(previewEnabled);

        // ���P�B�@�� visual�]�t AutoFitSprite2D�^
        RefreshPreviewVisual();
    }

    void SetIndex(int idx)
    {
        if (obstacleList == null) return;
        if (idx < 0 || idx >= obstacleList.Length) return;

        currentIndex = idx;
        SyncCurrentObstacle();
    }

    void SyncCurrentObstacle()
    {
        if (obstacleList != null && obstacleList.Length > 0)
        {
            currentIndex = Mathf.Clamp(currentIndex, 0, obstacleList.Length - 1);
            currentObstacle = obstacleList[currentIndex];
        }

        // ������ê�����s�w�� visual�]�t AutoFitSprite2D�^
        RefreshPreviewVisual();
    }

    Vector2 GetPlacePosition()
    {
        Vector3 mouse = cam.ScreenToWorldPoint(Mouse.current.position.ReadValue());
        mouse.z = 0f;

        // �ϥ� PlacementSystem ����l���ߡA�T�O�u�w����m�v�P�u��ک�m��m�v�@�P
        if (placementSystem != null && currentObstacle != null && currentObstacle.snapToGrid)
        {
            Vector2Int cell = placementSystem.WorldToCell(mouse);
            return placementSystem.CellToWorldCenter(cell);
        }

        return mouse;
    }

    bool CanPlaceAt(Vector2 pos)
    {
        if (currentObstacle == null) return false;

        // ���Φ���t�ΧP�_�]�D�n�W�h�^
        if (placementSystem != null)
        {
            Vector2Int cell = placementSystem.WorldToCell(pos);
            if (!placementSystem.CanPlace(currentObstacle, cell))
                return false;
        }

        // �A�Ϊ��z�����b�]�Y�p�@�I�קK�K��~�P�^
        Vector2 size = currentObstacle.FootprintWorld * 0.9f;
        Collider2D hit = Physics2D.OverlapBox(pos, size, 0f, blockMask);
        return hit == null;
    }

    // --------------------
    // Preview (Clone Prefab Visual + Tint Overlay)
    // --------------------

    void CreatePreviewGhost()
    {
        previewGO = new GameObject("PlacementPreview");
        previewGO.transform.SetParent(null);
        previewGO.SetActive(false);
    }

    void SetPreviewActive(bool active)
    {
        if (previewGO == null) return;

        if (!active)
        {
            previewGO.SetActive(false);
            return;
        }

        RefreshPreviewVisual();
        previewGO.SetActive(true);
    }

    // �֤ߡG�����ƻs prefab �̪� Visual�]�]�t AutoFitSprite2D / localScale�^�A�T�O�w���j�p == ��ڤj�p
    void RefreshPreviewVisual()
    {
        if (previewGO == null) return;

        if (currentObstacle == null || currentObstacle.prefab == null)
        {
            cachedData = null;
            cachedVisualSourceGO = null;
            DestroyPreviewChildren();
            return;
        }

        if (cachedData == currentObstacle && cachedVisualSourceGO != null) return;

        cachedData = currentObstacle;

        var srcSR = currentObstacle.prefab.GetComponentInChildren<SpriteRenderer>();
        if (srcSR == null)
        {
            cachedVisualSourceGO = null;
            DestroyPreviewChildren();
            return;
        }

        cachedVisualSourceGO = srcSR.gameObject;

        DestroyPreviewChildren();

        // Base�G�� sprite �b�z��
        previewBaseRoot = Instantiate(cachedVisualSourceGO, previewGO.transform).transform;
        previewBaseRoot.name = "BaseVisual";
        previewBaseSR = previewBaseRoot.GetComponent<SpriteRenderer>();

        // Tint�G�P�@�� Visual �A�ƻs�@���A�Ψ��|��
        previewTintRoot = Instantiate(cachedVisualSourceGO, previewGO.transform).transform;
        previewTintRoot.name = "TintVisual";
        previewTintSR = previewTintRoot.GetComponent<SpriteRenderer>();

        ApplySorting(previewBaseRoot, previewSortingOrder);
        ApplySorting(previewTintRoot, previewSortingOrder + 1);

        DisableAllColliders(previewBaseRoot);
        DisableAllColliders(previewTintRoot);

        UpdatePreviewColors(true);
        ApplyPreviewRotation();
    }

    void DestroyPreviewChildren()
    {
        if (previewBaseRoot != null) Destroy(previewBaseRoot.gameObject);
        if (previewTintRoot != null) Destroy(previewTintRoot.gameObject);

        previewBaseRoot = null;
        previewTintRoot = null;
        previewBaseSR = null;
        previewTintSR = null;
    }

    void ApplySorting(Transform root, int baseOrder)
    {
        var srs = root.GetComponentsInChildren<SpriteRenderer>(true);
        foreach (var sr in srs)
        {
            sr.sortingOrder = baseOrder + sr.sortingOrder;
        }
    }

    void DisableAllColliders(Transform root)
    {
        var cols = root.GetComponentsInChildren<Collider2D>(true);
        foreach (var c in cols) c.enabled = false;
    }

    void UpdatePreview()
    {
        if (previewGO == null) return;

        if (currentObstacle == null || currentObstacle.prefab == null)
        {
            previewGO.SetActive(false);
            return;
        }

        if (!previewGO.activeSelf) previewGO.SetActive(true);

        RefreshPreviewVisual();

        Vector2 pos = GetPlacePosition();
        previewGO.transform.position = pos;
        ApplyPreviewRotation();
        bool canPlace = CanPlaceAt(pos);
        UpdatePreviewColors(canPlace);
    }

    void UpdatePreviewColors(bool canPlace)
    {
        if (previewBaseSR == null || previewTintSR == null) return;

        Color baseC = Color.white;
        baseC.a = previewAlpha;
        previewBaseSR.color = baseC;

        Color tintC = canPlace ? Color.green : Color.red;
        tintC.a = previewTintAlpha;
        previewTintSR.color = tintC;
    }

    // =========================
    // Public API for InputMode
    // =========================

    public void SetIndex_Public(int idx)
    {
        SetIndex(idx);
    }

    public bool TryPlaceOnce_Public()
    {
        if (currentObstacle == null || currentObstacle.prefab == null) return false;
        if (Time.time < nextPlaceTime) return false;

        Vector2 placePos = GetPlacePosition();
        if (!CanPlaceAt(placePos)) return false;

        bool ok = placementSystem != null
            ? placementSystem.TryPlace(currentObstacle, placePos, currentRotation, out _)
            : false;

        if (placementSystem == null)
        {
            var go = Instantiate(currentObstacle.prefab, placePos, Quaternion.identity);
            var core = go.GetComponent<ObstacleCore2D>();
            if (core != null) core.data = currentObstacle;
            ok = true;
        }

        if (!ok) return false;

        nextPlaceTime = Time.time + currentObstacle.placeCooldown;
        return true;
    }

    /// <summary>
    /// Build �Ҧ����u��v�J�f�G��ƹ��Ҧb��l���w��m��ê���]������q�^�C
    /// �^�� true ���ܯu�����F��C
    /// </summary>
    public bool TryRemoveOnce_Public()
    {
        if (placementSystem == null) return false;
        if (Time.time < nextRemoveTime) return false;

        // �ΦP�@�M�ƹ�->��l�y�{�A�T�O���m/�w���@�P
        Vector2 pos = GetPlacePosition();
        Vector2Int cell = placementSystem.WorldToCell(pos);

        if (!placementSystem.TryGetAtCell(cell, out var core)) return false;
        if (core == null) return false;

        placementSystem.Remove(core);

        nextRemoveTime = Time.time + Mathf.Max(0f, removeCooldown);
        return true;
    }

    public void SetPreviewVisible_Public(bool visible)
    {
        previewEnabled = visible;
        SetPreviewActive(visible);
    }

    // �� InputMode �b legacy input �����ɡA�]��C�V��s�w����m�P��/�񪬺A
    public void UpdatePreview_Public()
    {
        if (!previewEnabled) return;
        UpdatePreview();
    }

    public void Rotate_Public(int delta)
    {
        // delta = +1 or -1
        currentRotation = (currentRotation + delta * 90) % 360;
        if (currentRotation < 0) currentRotation += 360;

        // �w���n�Y����
        ApplyPreviewRotation();
    }

    void ApplyPreviewRotation()
    {
        if (previewGO == null) return;
        previewGO.transform.rotation = Quaternion.Euler(0, 0, currentRotation);
    }
}
