using UnityEngine;
using System.Collections;

public class PlayerHealFeedback2D : MonoBehaviour
{
    [Header("References")]
    public PlayerHealth health;
    public SpriteRenderer spriteRenderer;
    public AudioClip healSfx;            // optional

    [Header("Flash")]
    public float flashDuration = 0.08f;
    public Color healColor = new Color(0.4f, 1f, 0.4f, 1f);

    Color originalColor;
    Coroutine flashCo;

    void Awake()
    {
        if (health == null) health = GetComponent<PlayerHealth>();
        if (spriteRenderer == null) spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        if (spriteRenderer != null)
            originalColor = spriteRenderer.color;
    }

    void OnEnable()
    {
        if (health != null)
            health.OnHealed += HandleHealed;
    }

    void OnDisable()
    {
        if (health != null)
            health.OnHealed -= HandleHealed;
    }

    void HandleHealed(float healedAmount)
    {
        // healedAmount �@�w > 0�]PlayerHealth.Heal �̤w�O�ҡ^
        if (spriteRenderer != null)
        {
            if (flashCo != null) StopCoroutine(flashCo);
            flashCo = StartCoroutine(FlashHeal());
        }

        // ���Ĩ��A�M�ת� AudioManager_2D�]���n�b Zone ���^
        if (healSfx != null && AudioManager_2D.Instance != null)
            AudioManager_2D.Instance.PlayGameplaySFX(healSfx);
    }

    IEnumerator FlashHeal()
    {
        // ���{��
        spriteRenderer.color = healColor;
        yield return new WaitForSeconds(flashDuration);

        // �٭�
        spriteRenderer.color = originalColor;
        flashCo = null;
    }
}
