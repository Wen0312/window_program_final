using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInputMode2D : MonoBehaviour
{
    public enum Mode { Combat, Build }

    [Header("Mode")]
    public Mode mode = Mode.Combat;

    [Header("Refs")]
    public WeaponController2D weaponController;   // �����β{�� WeaponController2D
    public PlayerWeaponInput weaponInput;         // �ΨӤ��Z���]�u�ΧA�� weapons[]�^
    public PlayerPlaceObstacle2D placer;          // �Ψө�m�P����

    //�s�W�GMove / Aim �]�� InputMode �Τ@���ȡ]�l�t�Τ��AŪ Input�^
    public TopDownPlayerMove2D mover;
    public PlayerAim2D aimer;

    [Header("Scroll Wheel")]
    public float wheelDeadZone = 0.05f;  // �קK�ܤp���u���ݰ�
    public bool invertWheel = false;     // �ݭn�ϦV�N��
    
    [Header("Map")]
    public MapBootstrapper2D mapBootstrapper;
    [Header("ADS camera")]
    public CameraFollow2D cameraFollow;

    [Header("Camera Base View (Play/Editor x Combat/Build)")]
    [Tooltip("Play Loadout + Combat ����¦���� (Orthographic Size)")]
    public float playCombatOrthoSize = 3.5f;

    [Tooltip("Editor Loadout + Combat ����¦���� (Orthographic Size)")]
    public float editorCombatOrthoSize = 10f;

    [Tooltip("Play Loadout + Build ����¦���� (Orthographic Size)")]
    public float playBuildOrthoSize = 7f;

    [Tooltip("Editor Loadout + Build ����¦���� (Orthographic Size)")]
    public float editorBuildOrthoSize = 9f;




    void Awake()
    {
        // �۰ʧ�]�ٱo�A�|��^
        if (weaponInput == null) weaponInput = GetComponent<PlayerWeaponInput>();
        if (weaponController == null && weaponInput != null) weaponController = weaponInput.weaponController;
        if (placer == null) placer = GetComponent<PlayerPlaceObstacle2D>();

        // Move / Aim �]�۰ʧ�
        if (mover == null) mover = GetComponent<TopDownPlayerMove2D>();
        if (aimer == null) aimer = GetComponent<PlayerAim2D>();

        if (mapBootstrapper == null)
            mapBootstrapper = UnityEngine.Object.FindFirstObjectByType<MapBootstrapper2D>();

        // CameraFollow�G�q�`���b MainCamera
        if (cameraFollow == null)
            cameraFollow = UnityEngine.Object.FindFirstObjectByType<CameraFollow2D>();
    }


    void Update()
    {
        if (Mouse.current == null || Keyboard.current == null) return;

        // ======================
        // Unified Move / Aim Input
        // ======================

        // --- Move (WASD / ��V��) ---
        Vector2 move = Vector2.zero;

        // WASD
        if (Keyboard.current.wKey.isPressed) move.y += 1;
        if (Keyboard.current.sKey.isPressed) move.y -= 1;
        if (Keyboard.current.aKey.isPressed) move.x -= 1;
        if (Keyboard.current.dKey.isPressed) move.x += 1;

        // ��V��]�i��A�O�d�A�쥻�ߺD�^
        if (Keyboard.current.upArrowKey.isPressed) move.y += 1;
        if (Keyboard.current.downArrowKey.isPressed) move.y -= 1;
        if (Keyboard.current.leftArrowKey.isPressed) move.x -= 1;
        if (Keyboard.current.rightArrowKey.isPressed) move.x += 1;

        move = move.normalized;


        if (mover != null)
            mover.SetMoveInput(move);

        // --- Aim (Mouse world position) ---
        if (aimer != null)
        {
            Vector3 mouse = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
            mouse.z = 0;
            aimer.SetAimWorldPosition(mouse);
        }

        // Alt�G�����Ҧ� + �P�ɶ}���w��
        if (Keyboard.current.leftAltKey.wasPressedThisFrame || Keyboard.current.rightAltKey.wasPressedThisFrame)
        {
            ToggleMode();
        }

        if (mode == Mode.Combat) HandleCombat();
        else HandleBuild();

        // ===== Loadout Switch (Editor / Play) =====
        // Hotkey: O
        if (Keyboard.current != null && Keyboard.current.oKey.wasPressedThisFrame)
        {
            if (mapBootstrapper != null && mapBootstrapper.map != null)
            {
                bool next = !mapBootstrapper.map.useEditorLoadouts;
                mapBootstrapper.ApplyLoadouts(next);

                Debug.Log("Loadout switched to: " + (next ? "EDITOR" : "PLAY"));
            }
            else
            {
                Debug.LogWarning("Loadout switch failed: mapBootstrapper or map is null.");
            }
        }


    }

    void ToggleMode()
    {
        if (mode == Mode.Combat)
        {
            // =========================
            // Combat �� Build
            // =========================
            mode = Mode.Build;

            if (placer != null)
                placer.SetPreviewVisible_Public(true);

            // Build �����\ ADS�]�u�v�T�欰�A���ʬ۾��^
            if (weaponController != null)
                weaponController.SetADS_Public(false);

            if (cameraFollow != null)
            {
                cameraFollow.SetADSOrthoSizeOverride_Public(0f);
                cameraFollow.SetADS_Public(false);
            }

            if (mover != null)
            {
                mover.SetADS_Public(false);
                mover.SetADSSpeedMultiplier_Public(0f);
            }
        }
        else
        {
            // =========================
            // Build �� Combat
            // =========================
            mode = Mode.Combat;

            if (placer != null)
                placer.SetPreviewVisible_Public(false);

            // �^ Combat �u�M ADS ���A�A���ʵ���
            if (weaponController != null)
                weaponController.SetADS_Public(false);

            if (cameraFollow != null)
            {
                cameraFollow.SetADSOrthoSizeOverride_Public(0f);
                cameraFollow.SetADS_Public(false);
            }

            if (mover != null)
            {
                mover.SetADS_Public(false);
                mover.SetADSSpeedMultiplier_Public(0f);
            }
        }
    }







    // ======================
    // Combat�]�g���Ҧ��^
    // ����=�g���B�u��=���Z���B�k��O�d
    // ======================
    void HandleCombat()
    {
        if (weaponController == null) return;
        if (weaponController.currentWeapon == null) return;

        // ADS: �k������i�J�A��}�h�X�]�� Combat Mode�^
        if (Mouse.current != null && cameraFollow != null)
        {
            bool ads = Mouse.current.rightButton.isPressed;

            // =========================
            // Weapon ADS�]�v�T���g�^
            // =========================
            weaponController.SetADS_Public(ads);

            // =========================
            // Move ADS�]�v�T���ʳt�ס^
            // =========================
            if (mover != null)
            {
                mover.SetADS_Public(ads);

                if (ads)
                {
                    // ADS �ɡG�Y�Z�����]�w���ʭ��v�A�h�мg
                    mover.SetADSSpeedMultiplier_Public(
                        weaponController.currentWeapon.adsSpeedMultiplierOverride
                    );
                }
                else
                {
                    // ��} ADS�G�M���мg�A�^�쨤��w�]��
                    mover.SetADSSpeedMultiplier_Public(0f);
                }
            }

            // =========================
            // Camera ADS�]���Y�Ի��^
            // =========================
            if (ads)
            {
                cameraFollow.SetADSOrthoSizeOverride_Public(
                    weaponController.currentWeapon.adsOrthoSizeOverride
                );
            }
            else
            {
                cameraFollow.SetADSOrthoSizeOverride_Public(0f);
            }

            cameraFollow.SetADS_Public(ads);
        }

        // Reload: R
        if (Keyboard.current.rKey.wasPressedThisFrame)
        {
            weaponController.TryReload();
        }

        // �g���]�̪Z���]�w�M�w�O�_�s�g�^
        bool fireInput = weaponController.currentWeapon.holdToFire
            ? Mouse.current.leftButton.isPressed
            : Mouse.current.leftButton.wasPressedThisFrame;

        if (fireInput)
        {
            Vector2 dir = GetAimDir();
            weaponController.TryShoot(dir);
        }

        // �u�������Z��
        int w = ReadWheelDelta();
        if (w != 0) TrySwitchWeapon(w);
    }






    // ======================
    // Build�]�سy�Ҧ��^
    // ����=��m�B�u��=����BQ/E=����B�k��O�d
    // ======================
    void HandleBuild()
    {
        if (placer == null) return;

        placer.UpdatePreview_Public();

        // ===== ����]Q / E�^=====
        if (Keyboard.current.qKey.wasPressedThisFrame)
        {
            placer.Rotate_Public(-1); // �f�ɰw
        }
        if (Keyboard.current.eKey.wasPressedThisFrame)
        {
            placer.Rotate_Public(+1); // ���ɰw
        }

        // ===== �u������ê�� =====
        int w = ReadWheelDelta();
        if (w != 0)
        {
            CycleObstacle(w);
        }

        // ===== �k���]�u���\ Editor Loadout�^=====
        // �u�b map.useEditorLoadouts == true �ɤ~���\��
        bool editorLoadout =
            mapBootstrapper != null &&
            mapBootstrapper.map != null &&
            mapBootstrapper.map.useEditorLoadouts;

        if (editorLoadout && Mouse.current.rightButton.wasPressedThisFrame)
        {
            placer.TryRemoveOnce_Public();
        }

        // ===== �����m =====
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            TryPlaceOnce();
        }
    }


    // ---- helpers ----

    Vector2 GetAimDir()
    {
        Vector3 mouse = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
        mouse.z = 0;
        return (Vector2)(mouse - weaponController.firePoint.position);
    }

    void TrySwitchWeapon(int delta)
    {
        if (weaponInput == null) return;

        weaponInput.SwitchWeapon_Public(delta);
    }

    void HandleDigitSwitch()
    {
        // �̤p�i�ΡG�����u�ΧA PlayerPlaceObstacle2D �� SetIndex
        if (Keyboard.current.digit1Key.wasPressedThisFrame) placer.SetIndex_Public(0);
        if (Keyboard.current.digit2Key.wasPressedThisFrame) placer.SetIndex_Public(1);
        if (Keyboard.current.digit3Key.wasPressedThisFrame) placer.SetIndex_Public(2);
        if (Keyboard.current.digit4Key.wasPressedThisFrame) placer.SetIndex_Public(3);
        if (Keyboard.current.digit5Key.wasPressedThisFrame) placer.SetIndex_Public(4);
        if (Keyboard.current.digit6Key.wasPressedThisFrame) placer.SetIndex_Public(5);
        if (Keyboard.current.digit7Key.wasPressedThisFrame) placer.SetIndex_Public(6);
        if (Keyboard.current.digit8Key.wasPressedThisFrame) placer.SetIndex_Public(7);
        if (Keyboard.current.digit9Key.wasPressedThisFrame) placer.SetIndex_Public(8);
    }

    void TryPlaceOnce()
    {
        // �� placer �ۤv���m/��l
        placer.TryPlaceOnce_Public();
    }

    void TrySetPreview(bool on)
    {
        // �A���s�� placer �� previewEnabled/SetPreviewActive�F�ª��S���C
        // �o�̥� SendMessage ����sĶ���ѡ]���N�I�s�A�S���N���L�^�C
        if (placer == null) return;

        placer.SendMessage("SetPreviewActive", on, SendMessageOptions.DontRequireReceiver);
    }

    int ReadWheelDelta()
    {
        if (Mouse.current == null) return 0;

        float y = Mouse.current.scroll.ReadValue().y;
        if (Mathf.Abs(y) < wheelDeadZone) return 0;

        int delta = y > 0 ? 1 : -1;
        if (invertWheel) delta = -delta;
        return delta;
    }

    void CycleObstacle(int delta)
    {
        if (placer == null) return;
        if (placer.obstacleList == null || placer.obstacleList.Length == 0) return;

        int len = placer.obstacleList.Length;
        int next = placer.currentIndex + delta;

        // wrap around
        if (next < 0) next = len - 1;
        if (next >= len) next = 0;

        placer.SetIndex_Public(next);

        // ���w���ߨ��s�]�A�w�g�� UpdatePreview_Public�^
        placer.UpdatePreview_Public();
    }
}
