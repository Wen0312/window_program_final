using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Projectile2D : MonoBehaviour
{
    public float lifeTime = 2f;

    Rigidbody2D rb;
    float damage;
    GameObject owner;
    bool hasHit = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    //�Τ@�γo��
    public void Launch(Vector2 dir, float speed, float dmg, GameObject ownerGO = null)
    {
        damage = dmg;
        owner = ownerGO;

        rb.linearVelocity = dir.normalized * speed;
        Destroy(gameObject, lifeTime);
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        //�u�R���@��
        if (hasHit) return;

        // �קK����ۤv
        if (owner != null && other.transform.root.gameObject == owner) return;

        // ---------- Wall / Blocking Obstacle ----------
        // ������Ρu�|���ת���ê���v�� �l�u����
        int layer = other.gameObject.layer;
        bool isWall = layer == LayerMask.NameToLayer("Wall");

        var obstacleCore = other.GetComponentInParent<ObstacleCore2D>();
        bool blocksByObstacle =
            obstacleCore != null &&
            obstacleCore.data != null &&
            obstacleCore.data.blocksMovement;

        if (isWall || blocksByObstacle)
        {
            hasHit = true;

            // ����q�~���]�� / �o���^
            var dmgableObs = other.GetComponentInParent<IDamageable>();
            if (dmgableObs != null)
            {
                dmgableObs.TakeDamage(damage, transform.position, owner);
            }

            Destroy(gameObject);
            return;
        }
        // ---------------------------------------------

        // ---------- Non-blocking Obstacle (Wire / Poison) ----------
        // �����ת��ϰ�G���������A���v�T�l�u
        if (obstacleCore != null &&
            obstacleCore.data != null &&
            obstacleCore.data.blocksMovement == false)
        {
            return;
        }
        // ----------------------------------------------------------

        //�� owner �M�w����
        var root = other.transform.root;

        if (owner != null)
        {
            if (owner.CompareTag("Player") && !root.CompareTag("Enemy")) return;
            if (owner.CompareTag("Enemy") && !root.CompareTag("Player")) return;
        }

        // �u���R���ĤH / ���a
        var dmgable = other.GetComponentInParent<IDamageable>();
        if (dmgable != null)
        {
            hasHit = true;   //�u���o�̤~�аO�R��
            dmgable.TakeDamage(damage, transform.position, owner);
            Destroy(gameObject);
        }
    }




}
