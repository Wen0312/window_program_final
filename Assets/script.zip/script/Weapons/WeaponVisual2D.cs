using UnityEngine;

/// <summary>
/// WeaponVisual2D
/// �M���B�z�u�Z����ı��ۺ˷Ǳ���v�A���B�z�����B��Ū Input
/// - ��ƨӷ��GWeaponData�]ScriptableObject�^
/// - ��V�ӷ��GPlayerAim2D
/// - �ͩR�g���G��� WeaponController2D.currentWeapon
/// </summary>
public class WeaponVisual2D : MonoBehaviour
{
    [Header("Refs")]
    public WeaponController2D weaponController;
    public PlayerAim2D aimer;

    [Header("Render")]
    public SpriteRenderer spriteRenderer;



    WeaponData currentWeapon;

    // ��Ǧ�m�]�Ӧ� WeaponData.weaponSpriteLocalOffset�^
    Vector3 baseLocalPos;

    // ��y�����]WeaponVisual local space�A�M�Ψ� Sprite localPosition�^
    Vector3 recoilOffsetLocal;

    // ��y���ס]�|�[�b Aim ����W�^
    float recoilRotZ;

    // Sprite ��l��m�]local�^
    Vector3 spriteBaseLocalPos;

    void Awake()
    {
        // �۰ʧ�A�ٱo�A�|��
        if (weaponController == null)
            weaponController = GetComponentInParent<WeaponController2D>();

        if (aimer == null)
            aimer = GetComponentInParent<PlayerAim2D>();

        if (spriteRenderer == null)
            spriteRenderer = GetComponentInChildren<SpriteRenderer>();
    }

    void LateUpdate()
    {
        if (weaponController == null) return;
        if (weaponController.currentWeapon == null)
        {
            SetVisible(false);
            return;
        }

        if (currentWeapon != weaponController.currentWeapon)
        {
            ApplyWeaponVisual(weaponController.currentWeapon);
        }

        // 1) ����s recoil �ƭ�
        UpdateRecoil(Time.deltaTime);

        // 2) �A���˷Ǳ���]�� recoilRotZ �[�W�h�^
        UpdateAimRotation();

        // 3) �̫�M�� Sprite ��h�첾
        ApplyRecoilLocalPosition();
    }



    // =========================
    // Public API�]�� WeaponController �b�u���\�}���v�ɩI�s�^
    // =========================
    /// <summary>
    /// �}�����\��I�s�GĲ�o�Z����y�]�u�v�T��ı�A���v�T�Ǥ�/�u�D�^
    /// strength�G�i�ΨӰ��żu/�j�j��y��j�]1 = �зǡ^
    /// </summary>
    // =========================
    // Public API�]�� WeaponController �b�u���\�}���v�ɩI�s�^
    // =========================
    public void KickRecoil_Public(float strength = 1f)
    {
        if (aimer == null) return;

        WeaponData w = weaponController != null
            ? weaponController.currentWeapon
            : currentWeapon;

        if (w == null) return;

        Vector2 aimDir = aimer.AimDir;
        if (aimDir.sqrMagnitude < 0.0001f) return;
        aimDir.Normalize();

        // ADS multiplier�]�uŪ���A�^
        float adsMul = 1f;
        if (weaponController != null && weaponController.IsADS_Public())
            adsMul = Mathf.Max(0f, w.adsRecoilMultiplier);

        float s = Mathf.Max(0.01f, strength) * adsMul;

        // �@�ɤ�V�]���Ϥ�V���^
        Vector3 worldKickDir = -(Vector3)aimDir;

        // ����ץ��G��V�ন WeaponVisual local
        Vector3 localKickDir = transform.InverseTransformDirection(worldKickDir);

        // �첾��y
        recoilOffsetLocal += localKickDir.normalized * (w.recoilKickDistance * s);
        float maxD = Mathf.Max(0.0001f, w.recoilMaxDistance);
        if (recoilOffsetLocal.magnitude > maxD)
            recoilOffsetLocal = recoilOffsetLocal.normalized * maxD;

        // �����y
        float sign = w.recoilRandomRotSign
            ? (Random.value < 0.5f ? -1f : 1f)
            : 1f;

        recoilRotZ += sign * (w.recoilKickRotationDeg * s);
    }





    // =========================
    // Core
    // =========================


    void ApplyWeaponVisual(WeaponData data)
    {
        currentWeapon = data;

        if (spriteRenderer == null)
            return;

        if (data.weaponSprite == null)
        {
            SetVisible(false);
            return;
        }

        SetVisible(true);

        spriteRenderer.sprite = data.weaponSprite;
        spriteRenderer.sortingOrder = data.weaponSortingOrder;

        // �O����Ǧ�m�]���� recoil ���H�o�Ӭ���ǡ^
        spriteRenderer.transform.localPosition = data.weaponSpriteLocalOffset;
        spriteBaseLocalPos = spriteRenderer.transform.localPosition;
        // �M�Υ��a�Y��
        transform.localScale = new Vector3(
            data.weaponSpriteLocalScale.x,
            data.weaponSpriteLocalScale.y,
            1f
        );

        // ���^���ǡ]�קK���j�ݯd�����^
        recoilOffsetLocal = Vector3.zero;
        recoilRotZ = 0f;
        // ��l���ס]�q�`�O�� sprite ���u�¥k�v��� AimDir�^
        transform.localRotation = Quaternion.Euler(0f, 0f, data.weaponSpriteAngleOffset);
    }

    void UpdateRecoil(float dt)
    {
        if (currentWeapon == null)
            return;

        recoilOffsetLocal = Vector3.Lerp(
            recoilOffsetLocal,
            Vector3.zero,
            1f - Mathf.Exp(-currentWeapon.recoilReturnSpeed * dt)
        );

        recoilRotZ = Mathf.Lerp(
            recoilRotZ,
            0f,
            1f - Mathf.Exp(-currentWeapon.recoilRotReturnSpeed * dt)
        );
    }
    void UpdateAimRotation()
    {
        if (aimer == null) return;
        if (currentWeapon == null) return;

        Vector2 aimDir = aimer.AimDir;
        if (aimDir.sqrMagnitude < 0.0001f) return;

        float angle = Mathf.Atan2(aimDir.y, aimDir.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.Euler(
            0f,
            0f,
            angle + currentWeapon.weaponSpriteAngleOffset + recoilRotZ
        );

        if (currentWeapon.weaponFlipOnAimLeft)
        {
            Vector3 scale = transform.localScale;
            scale.y = Mathf.Abs(scale.y) * (aimDir.x < 0 ? -1 : 1);
            transform.localScale = scale;
        }
    }



    void ApplyRecoilLocalPosition()
    {
        if (spriteRenderer == null) return;

        spriteRenderer.transform.localPosition =
            spriteBaseLocalPos + recoilOffsetLocal;
    }

    void SetVisible(bool visible)
    {
        if (spriteRenderer != null)
            spriteRenderer.enabled = visible;
    }
    void OnEnable()
    {
        if (weaponController != null)
            weaponController.OnShotSuccess_Recoil += KickRecoil_Public;
    }

    void OnDisable()
    {
        if (weaponController != null)
            weaponController.OnShotSuccess_Recoil -= KickRecoil_Public;
    }

}
