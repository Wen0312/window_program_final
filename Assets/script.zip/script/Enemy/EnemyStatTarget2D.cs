using UnityEngine;

public class EnemyStatTarget2D : MonoBehaviour, IStatTarget2D
{
    public EnemyHealth health;
    public EnemyAI_ChasePlayer2D chase;

    float baseSpeed;
    bool inited = false;

    readonly System.Collections.Generic.Dictionary<object, float> speedMult = new();

    void Awake()
    {
        if (health == null) health = GetComponent<EnemyHealth>();
        if (chase == null) chase = GetComponent<EnemyAI_ChasePlayer2D>();
        Init();
    }

    void Init()
    {
        if (inited || chase == null) return;
        baseSpeed = chase.moveSpeed;
        inited = true;
    }

    public void DealDamage(float amount, Vector2 hitPoint, GameObject instigator)
    {
        if (health == null) return;
        health.TakeDamage(amount, hitPoint, instigator);
    }

    // �s�W�G���F�ŦX IStatTarget2D �����]�ثe�ĤH���ݭn�^��i���d�š^
    public void Heal(float amount)
    {
        // intentionally empty
        // �Y���ӼĤH�ݭn�^��G�b EnemyHealth �W�[ Heal(amount) ��A�b���I�s�Y�i
        // if (health == null) return;
        // health.Heal(amount);
    }

    public void SetMoveSpeedMultiplier(object source, float multiplier)
    {
        Init();
        if (chase == null) return;

        speedMult[source] = Mathf.Clamp01(multiplier);
        ApplySpeed();
    }

    public void ClearMoveSpeedMultiplier(object source)
    {
        Init();
        if (chase == null) return;

        speedMult.Remove(source);
        ApplySpeed();
    }

    void ApplySpeed()
    {
        float m = 1f;
        foreach (var kv in speedMult)
            m = Mathf.Min(m, kv.Value);

        chase.moveSpeed = baseSpeed * m;
    }
}
