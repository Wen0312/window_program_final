using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// SpecialEnemyController2D
/// �S���ĤH runtime ���
/// - �u�t�d�u�� SpecialEnemyData2D ����O�M��]�_�ӡv
/// - ����g�J�� EnemyAI / Attack �}��
/// </summary>
public class SpecialEnemyController2D : MonoBehaviour
{
    [Header("Data")]
    public SpecialEnemyData2D data; // �s�W

    [Header("Auto Find")]
    public EnemyHealth health;      // �s�W

    SpecialEnemyContext2D ctx;

    // �s�W�Gruntime �H�udata.abilities �� index�v����A���\�����O null
    readonly List<SpecialEnemyAbilityRuntime2D> runtimes = new(); // �|�s�P���ס]�t null�^ // �s�W

    [Header("Auto active")]
    // �s�W�GAbility �ҥΪ��A�]�H data.abilities index ����^
    bool[] abilityEnabled; // �s�W

    void Awake()
    {
        if (health == null) health = GetComponent<EnemyHealth>();

        ctx = new SpecialEnemyContext2D
        {
            gameObject = gameObject,
            transform = transform,
            health = health,
            rb = GetComponent<Rigidbody2D>(),
            player = null,
            selfStatTarget = GetComponent<IStatTarget2D>(),
        };

        // �� player�]���b Enemy Awake �ç��ҡA�u���@���^
        var p = GameObject.FindGameObjectWithTag("Player");
        if (p != null) ctx.player = p.transform;

        BuildRuntimes();
        HookHealthEvents();
    }

    void OnDestroy()
    {
        UnhookHealthEvents();
    }

    void Update()
    {
        if (runtimes.Count == 0) return;

        float dt = Time.deltaTime;
        for (int i = 0; i < runtimes.Count; i++)
        {
            if (abilityEnabled != null && i < abilityEnabled.Length && !abilityEnabled[i]) continue; // �s�W
            var rt = runtimes[i];
            if (rt == null) continue; // �s�W
            rt.Tick(ctx, dt);
        }
    }

    void BuildRuntimes()
    {
        runtimes.Clear();
        if (data == null || data.abilities == null) return;

        // �s�W�G�H data.abilities.Count ���D�Aruntimes �]�n����P�˪���
        int n = data.abilities.Count; // �s�W

        abilityEnabled = new bool[n]; // �s�W
        for (int i = 0; i < n; i++)
            abilityEnabled[i] = true; // �w�]�ҥ�

        // �s�W�G���� n �Ӧ�m�]�i�� null�^
        for (int i = 0; i < n; i++) runtimes.Add(null); // �s�W

        // �s�W�G�P index ��m�إ� runtime�]�Y��O�O null�A�Ӯ�O�� null�^
        for (int i = 0; i < n; i++)
        {
            var a = data.abilities[i];
            if (a == null) continue;

            var rt = a.CreateRuntime();
            if (rt == null) continue;

            runtimes[i] = rt; // �s�W�G��� index
            rt.Init(ctx);
        }
    }

    void HookHealthEvents()
    {
        if (health == null) return;
        health.OnDamaged += HandleDamaged;
        health.OnDead += HandleDead;

        health.OnHPChanged += HandleHPChanged; // �s�W
    }

    void UnhookHealthEvents()
    {
        if (health == null) return;
        health.OnDamaged -= HandleDamaged;
        health.OnDead -= HandleDead;

        health.OnHPChanged -= HandleHPChanged; // �s�W
    }

    // �s�W
    void HandleHPChanged(float current, float max)
    {
        for (int i = 0; i < runtimes.Count; i++)
        {
            if (abilityEnabled != null && i < abilityEnabled.Length && !abilityEnabled[i]) continue; // �s�W
            var rt = runtimes[i];
            if (rt == null) continue; // �s�W
            rt.OnHPChanged(ctx, current, max);
        }
    }

    void HandleDamaged(float damage, Vector2 hitPoint, GameObject instigator)
    {
        for (int i = 0; i < runtimes.Count; i++)
        {
            if (abilityEnabled != null && i < abilityEnabled.Length && !abilityEnabled[i]) continue; // �s�W
            var rt = runtimes[i];
            if (rt == null) continue; // �s�W
            rt.OnDamaged(ctx, damage, hitPoint, instigator);
        }
    }

    void HandleDead()
    {
        // �`�N�GEnemyHealth.Die() ���| Destroy(gameObject)
        // �]�� OnDeath �u���̫�@��Ĳ�o�]���n�b�� Instantiate �ܭ����F��^
        for (int i = 0; i < runtimes.Count; i++)
        {
            if (abilityEnabled != null && i < abilityEnabled.Length && !abilityEnabled[i]) continue; // �s�W
            var rt = runtimes[i];
            if (rt == null) continue; // �s�W
            rt.OnDeath(ctx);
        }
    }

    // �s�W
    public void EnableAbilityByIndex(int index)
    {
        if (abilityEnabled == null) return;
        if (index < 0 || index >= abilityEnabled.Length) return;
        abilityEnabled[index] = true;
    }

    // �s�W�G�� ShieldPhase �ΡA�}�ޫe�����O
    public void DisableAbilityByIndex(int index) // �s�W
    {
        if (abilityEnabled == null) return;
        if (index < 0 || index >= abilityEnabled.Length) return;
        abilityEnabled[index] = false;
    }
}
