using UnityEngine;

/// <summary>
/// ShieldPhaseAbility2D
/// �@�� Phase�G�����ޡB�A����
/// - ���� EnemyHealth
/// - OnDamaged ���ƫ�q���A�]���� IHealable ���ոɦ^�]����^
/// </summary>
[CreateAssetMenu(menuName = "Game/Enemy/Abilities/ShieldPhaseAbility2D", fileName = "ShieldPhaseAbility2D")]
public class ShieldPhaseAbility2D : SpecialEnemyAbilityData2D
{
    [Header("Shield")]
    public float shieldHP = 20f;
    public bool invulnerableWhileShieldUp = true; // �@�ަs�b�ɹ��թ������

    [Header("Break Effects")]
    public AudioClip shieldBreakSfx;
    public GameObject shieldBreakVfx;

    [Header("Phase Unlock")]
    [Tooltip("�@�ޯ}����n���ꪺ Ability ���ޡ]���V�P�@�� SpecialEnemyData2D.abilities�^")]
    public int[] unlockAbilityIndices;

    [Header("Phase Lock (optional)")]
    [Tooltip("�@�ަs�b�ɭn����� Ability ���ޡ]�Ҧp�l��/�r�鵥�^")]
    public int[] lockAbilityIndices; // �s�W�]�i��^

    public override SpecialEnemyAbilityRuntime2D CreateRuntime()
    {
        return new Runtime(this);
    }

    class Runtime : SpecialEnemyAbilityRuntime2D
    {
        readonly ShieldPhaseAbility2D data;

        float currentShield;
        bool broken = false;
        bool locksApplied = false;

        public Runtime(ShieldPhaseAbility2D data)
        {
            this.data = data;
        }

        // �s�W�G�Τ@�q Boss Root�]parent chain�^�� component�A�קK ctx.gameObject ���O root �ɧ줣��
        T GetFromBossRoot<T>(SpecialEnemyContext2D ctx) where T : Component
        {
            // SpecialEnemyContext2D �O struct�A���� ctx == null

            // ctx.gameObject �i��O Ability Host�]�l����^�A�]���� InParent ���W��
            if (ctx.gameObject != null)
            {
                var c = ctx.gameObject.GetComponentInParent<T>();
                if (c != null) return c;
            }

            // fallback�G�� transform �]���W��
            if (ctx.transform != null)
            {
                var c = ctx.transform.GetComponentInParent<T>();
                if (c != null) return c;
            }

            return null;
        }


        public override void Init(SpecialEnemyContext2D ctx)
        {
            currentShield = Mathf.Max(0f, data.shieldHP);

            // �s�W�GBoss ���q��r�]�p�G���� BossPhaseState2D�^
            var phase = GetFromBossRoot<BossPhaseState2D>(ctx); // �s�W
            if (phase != null) phase.SetPhase("Shield");

            // �s�W�G�@�޴������O�]Phase 1�^
            var controller = GetFromBossRoot<SpecialEnemyController2D>(ctx); // �s�W
            if (controller != null && data.lockAbilityIndices != null && !locksApplied)
            {
                for (int i = 0; i < data.lockAbilityIndices.Length; i++)
                    controller.DisableAbilityByIndex(data.lockAbilityIndices[i]);
                locksApplied = true;
            }
        }

        public override void OnDamaged(SpecialEnemyContext2D ctx, float damage, Vector2 hitPoint, GameObject instigator)
        {
            if (broken) return;

            // ���@��
            currentShield -= Mathf.Max(0f, damage);

            // ���թ������]EnemyHealth �S Heal�A�� IHealable�^
            if (data.invulnerableWhileShieldUp && ctx.gameObject != null)
            {
                // interface ���ਫ where T: Component ���x���u��
                var healable = ctx.gameObject.GetComponentInParent<IHealable>();
                if (healable != null)
                {
                    healable.Heal(damage);
                }
            }

            if (currentShield <= 0f)
            {
                BreakShield(ctx);
            }
        }



        void BreakShield(SpecialEnemyContext2D ctx)
        {
            if (broken) return;
            broken = true;

            // SFX
            if (data.shieldBreakSfx != null)
                AudioManager_2D.Instance.PlayGameplaySFX(data.shieldBreakSfx);

            // VFX
            if (data.shieldBreakVfx != null && ctx.transform != null)
                Object.Instantiate(data.shieldBreakVfx, ctx.transform.position, Quaternion.identity);

            // �����O�]Phase 2�^
            var controller = GetFromBossRoot<SpecialEnemyController2D>(ctx); // �s�W
            if (controller != null && data.unlockAbilityIndices != null)
            {
                for (int i = 0; i < data.unlockAbilityIndices.Length; i++)
                    controller.EnableAbilityByIndex(data.unlockAbilityIndices[i]);
            }

            // �s�W�GBoss ���q��r
            var phase = GetFromBossRoot<BossPhaseState2D>(ctx); // �s�W
            if (phase != null) phase.SetPhase("Phase 2");
        }
    }
}
