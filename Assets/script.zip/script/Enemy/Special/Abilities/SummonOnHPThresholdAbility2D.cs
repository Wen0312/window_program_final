using UnityEngine;

/// <summary>
/// SummonOnHPThresholdAbility2D
/// ��q���e�l��GHP �C��Y��ҫ�}�l�l��p��
/// - ���� EnemyAI / EnemyHealth
/// - �z�L EnemyHealth.OnHPChanged ���o current/max
/// - �i�]�w�G�uĲ�o�@�� or �C��q����l��]cooldown�^
/// </summary>
[CreateAssetMenu(menuName = "Game/Enemy/Abilities/SummonOnHPThresholdAbility2D", fileName = "SummonOnHPThresholdAbility2D")]
public class SummonOnHPThresholdAbility2D : SpecialEnemyAbilityData2D
{
    [Header("Trigger")]
    [Range(0f, 1f)]
    public float hpPercentThreshold = 0.5f;   // �Ҧp 0.5 = 50% �H�U�Ұ�
    public bool summonOnce = true;            // true�G�u�b�Ĥ@���^�}���e�l�@��

    [Header("Summon")]
    public GameObject[] minionPrefabs;        // �n�l���ĤH prefab�]�i�h���H���^
    public int summonCount = 2;
    public float spawnRadius = 2.0f;

    [Tooltip("�C��q����l��ɪ��N�o�]���^�FsummonOnce=true �ɤ��|�Ψ� nextTime ����s��Ĳ�o")]
    public float cooldown = 6f;

    [Tooltip("�̦h�l�ꦸ�ơF0 ���ܤ�����")]
    public int maxActivations = 0;

    [Header("Spawn Safety (optional)")]
    public LayerMask blockedMask;            // �Y�Q�קK�ͦ��b�𤺡A�i���w blocking layers
    public float blockedCheckRadius = 0.15f; // OverlapCircle �ˬd�b�|
    public int maxTryPerMinion = 8;          // �C�� minion ���մX�����I

    [Header("VFX/SFX (optional)")]
    public GameObject summonVfxPrefab;
    public AudioClip summonSfx;

    public override SpecialEnemyAbilityRuntime2D CreateRuntime()
    {
        return new Runtime(this);
    }

    class Runtime : SpecialEnemyAbilityRuntime2D
    {
        readonly SummonOnHPThresholdAbility2D data;

        float hpRatio = 1f;
        bool thresholdReached = false;
        bool didOnce = false;
        float nextTime = 0f;
        int activations = 0;

        public Runtime(SummonOnHPThresholdAbility2D data)
        {
            this.data = data;
        }

        public override void OnHPChanged(SpecialEnemyContext2D ctx, float current, float max)
        {
            if (max <= 0f) return;
            hpRatio = current / max;

            // �Ĥ@���^�}���e�G�аO
            if (!thresholdReached && hpRatio <= data.hpPercentThreshold)
            {
                thresholdReached = true;
            }
        }

        public override void Tick(SpecialEnemyContext2D ctx, float dt)
        {
            if (!thresholdReached) return;

            if (data.summonOnce && didOnce) return;

            if (data.maxActivations > 0 && activations >= data.maxActivations) return;

            if (Time.time < nextTime) return;

            // summonOnce�G�Ĥ@��Ĳ�o��N�����F�_�h����l��]cooldown�^
            DoSummon(ctx);

            activations++;
            didOnce = data.summonOnce;

            nextTime = Time.time + Mathf.Max(0.1f, data.cooldown);
        }

        void DoSummon(SpecialEnemyContext2D ctx)
        {
            if (ctx.transform == null) return;
            if (data.minionPrefabs == null || data.minionPrefabs.Length == 0) return;

            Vector3 center = ctx.transform.position;

            // SFX
            if (data.summonSfx != null)
            {
                AudioManager_2D.Instance.PlayGameplaySFX(data.summonSfx);
            }

            // VFX�]�����I�^
            if (data.summonVfxPrefab != null)
            {
                Object.Instantiate(data.summonVfxPrefab, center, Quaternion.identity);
            }

            int count = Mathf.Max(1, data.summonCount);

            for (int i = 0; i < count; i++)
            {
                var prefab = data.minionPrefabs[Random.Range(0, data.minionPrefabs.Length)];
                if (prefab == null) continue;

                Vector3 spawnPos = FindSpawnPos(center);

                Object.Instantiate(prefab, spawnPos, Quaternion.identity);
            }
        }

        Vector3 FindSpawnPos(Vector3 center)
        {
            // �S���]�w blockedMask�G�����H���I
            if (data.blockedMask.value == 0)
            {
                Vector2 off = Random.insideUnitCircle * data.spawnRadius;
                return center + (Vector3)off;
            }

            // �� blockedMask�G��@�Ӥ����|����m
            int tries = Mathf.Max(1, data.maxTryPerMinion);
            for (int t = 0; t < tries; t++)
            {
                Vector2 off = Random.insideUnitCircle * data.spawnRadius;
                Vector3 p = center + (Vector3)off;

                var hit = Physics2D.OverlapCircle(p, data.blockedCheckRadius, data.blockedMask);
                if (hit == null) return p;
            }

            // �䤣��N�h�^���ߪ���
            return center;
        }
    }
}
