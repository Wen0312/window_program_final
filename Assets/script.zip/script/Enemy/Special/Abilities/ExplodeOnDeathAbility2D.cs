using UnityEngine;

/// <summary>
/// ExplodeOnDeathAbility2D
/// ���`�z���]���z���^
/// - ���� EnemyHealth.Die()
/// - �z�L EnemyHealth.OnDead Ĳ�o
/// </summary>
[CreateAssetMenu(menuName = "Game/Enemy/Abilities/ExplodeOnDeathAbility2D", fileName = "ExplodeOnDeathAbility2D")]
public class ExplodeOnDeathAbility2D : SpecialEnemyAbilityData2D
{
    [Header("Explosion")]
    public float radius = 2.5f;
    public float damage = 3f;
    public LayerMask affectMask;
    public GameObject vfxPrefab;

    [Header("SFX")] // �s�W
    public AudioClip explodeSfx; // �s�W

    public override SpecialEnemyAbilityRuntime2D CreateRuntime()
    {
        return new Runtime(this);
    }

    class Runtime : SpecialEnemyAbilityRuntime2D
    {
        readonly ExplodeOnDeathAbility2D data;
        bool done = false;

        public Runtime(ExplodeOnDeathAbility2D data)
        {
            this.data = data;
        }

        public override void OnDeath(SpecialEnemyContext2D ctx)
        {
            if (done) return;
            done = true;

            Vector3 pos = ctx.transform != null ? ctx.transform.position : Vector3.zero;

            // ===== SFX�]�@���ʡ^ =====
            if (data.explodeSfx != null)
            {
                AudioManager_2D.Instance.PlayGameplaySFX(data.explodeSfx);
            }

            // ===== VFX =====
            if (data.vfxPrefab != null)
            {
                Object.Instantiate(data.vfxPrefab, pos, Quaternion.identity);
            }

            // ===== Damage =====
            Collider2D[] hits = Physics2D.OverlapCircleAll(pos, data.radius, data.affectMask);
            for (int i = 0; i < hits.Length; i++)
            {
                var col = hits[i];
                if (col == null) continue;
                if (ctx.gameObject != null && col.gameObject == ctx.gameObject) continue;

                var dmg = col.GetComponentInParent<IDamageable>();
                if (dmg != null)
                {
                    dmg.TakeDamage(data.damage, pos, ctx.gameObject);
                }
            }
        }
    }
}
