using UnityEngine;

/// <summary>
/// SpawnEndGamePointOnDeathAbility2D
/// Boss ���`�ɥͦ� EndGamePoint�]�L���I�^
/// - ���� EnemyHealth
/// - ���v�T EnemyHealth.dropPrefab�]Boss �٬O�i�H���@��ԧQ�~�^
/// - �z�L SpecialEnemyController2D �� OnDeath Ĳ�o
/// </summary>
[CreateAssetMenu(menuName = "Game/Enemy/Abilities/SpawnEndGamePointOnDeathAbility2D", fileName = "SpawnEndGamePointOnDeathAbility2D")]
public class SpawnEndGamePointOnDeathAbility2D : SpecialEnemyAbilityData2D
{
    [Header("Prefab")]
    public GameObject endGamePointPrefab; // �� EndGamePoint.prefab �i��

    [Header("Offset")]
    public Vector2 spawnOffset = Vector2.zero; // �i��G�ͦ������]�Ҧp�y�L���W�^

    [Header("Optional")]
    public AudioClip spawnSfx;     // �i��
    public GameObject spawnVfx;    // �i��

    public override SpecialEnemyAbilityRuntime2D CreateRuntime()
    {
        return new Runtime(this);
    }

    class Runtime : SpecialEnemyAbilityRuntime2D
    {
        readonly SpawnEndGamePointOnDeathAbility2D data;
        bool done = false;

        public Runtime(SpawnEndGamePointOnDeathAbility2D data)
        {
            this.data = data;
        }

        public override void OnDeath(SpecialEnemyContext2D ctx)
        {
            if (done) return;
            done = true;

            if (data.endGamePointPrefab == null) return;

            Vector3 pos = ctx.transform != null ? ctx.transform.position : Vector3.zero;
            pos += (Vector3)data.spawnOffset;

            // SFX�]�@���ʡ^
            if (data.spawnSfx != null)
            {
                AudioManager_2D.Instance.PlayGameplaySFX(data.spawnSfx);
            }

            // VFX�]�i��^
            if (data.spawnVfx != null)
            {
                Object.Instantiate(data.spawnVfx, pos, Quaternion.identity);
            }

            // �ͦ� EndGamePoint
            Object.Instantiate(data.endGamePointPrefab, pos, Quaternion.identity);
        }
    }
}
