using UnityEngine;
using System;

public class EnemyHealth : MonoBehaviour, IDamageable
{
    public float maxHP = 5f;

    //�ƥ�G�~�����{�h��
    public event Action<float, float> OnHPChanged; // (current, max)
    public event Action<float, Vector2, GameObject> OnDamaged; // (damage, hitPoint, instigator)
    public event Action OnDead;

    public GameObject dropPrefab;      // �i��G���`����
    public float dropChance = 0.3f;    // �i��G0~1
    bool dead = false;
    Collider2D[] cols;
    float hp;

    void Awake()
    {
        hp = maxHP;
        cols = GetComponentsInChildren<Collider2D>();
    }
    public void TakeDamage(float amount, Vector2 hitPoint, GameObject instigator)
    {
        if (dead) return;

        hp -= amount;
        OnDamaged?.Invoke(amount, hitPoint, instigator);
        OnHPChanged?.Invoke(hp, maxHP);

        if (hp <= 0f)
        {
            Die();
        }
    }

    void Die()
    {
        dead = true;

        //�ߨ����I���G�קK�u���F�ٯ�Q���v
        foreach (var c in cols) c.enabled = false;
        OnDead?.Invoke();

        if (dropPrefab != null && UnityEngine.Random.value < dropChance)
        {
            Instantiate(dropPrefab, transform.position, Quaternion.identity);
        }

        Destroy(gameObject);
    }
}

