using System.Collections.Generic;
using UnityEngine;

public class PlacementSystem2D : MonoBehaviour
{
    [Header("Grid")]
    public float cellSize = 1f;
    public Vector3 origin = Vector3.zero;

    // ����G�C������@�� obstacle�]��K���/�d�ߡ^
    readonly Dictionary<Vector2Int, ObstacleCore2D> occupied = new();

    void Awake()
    {
        // (�i����ܹ��) �����@�}�l�N��{����ê�����U�i����
        // �o�˧A�Ρu�a�Ϲw�\�v�� Scene �̥���n����/��/zone�A���|�Q�����Ů�
        RegisterExistingObstacles();
    }

    public Vector2Int WorldToCell(Vector3 world)
    {
        Vector3 p = world - origin;
        int x = Mathf.FloorToInt(p.x / cellSize);
        int y = Mathf.FloorToInt(p.y / cellSize);
        return new Vector2Int(x, y);
    }

    public Vector3 CellToWorldCenter(Vector2Int cell)
    {
        float x = (cell.x + 0.5f) * cellSize;
        float y = (cell.y + 0.5f) * cellSize;
        return origin + new Vector3(x, y, 0f);
    }

    static IEnumerable<Vector2Int> EnumerateFootprint(Vector2Int originCell, Vector2Int size)
    {
        for (int dx = 0; dx < size.x; dx++)
            for (int dy = 0; dy < size.y; dy++)
                yield return new Vector2Int(originCell.x + dx, originCell.y + dy);
    }

    public bool CanPlace(ObstacleData data, Vector2Int cell)
    {
        if (data == null) return false;
        var size = data.footprintCells;

        foreach (var c in EnumerateFootprint(cell, size))
            if (occupied.ContainsKey(c)) return false;

        return true;
    }
    public bool TryPlace(ObstacleData data, Vector3 worldPos, int rotation, out ObstacleCore2D placed)
    {
        placed = null;
        if (data == null || data.prefab == null) return false;

        Vector2Int cell = WorldToCell(worldPos);

        if (!CanPlace(data, cell)) return false;

        // ��m�G�Ψt�� cellSize�A���� data.gridSize�]�קK�P�����h�M gridSize�^
        Vector3 spawnPos = data.snapToGrid ? CellToWorldCenter(cell) : worldPos;

        Quaternion rotQ = Quaternion.Euler(0f, 0f, rotation);
        GameObject go = Instantiate(data.prefab, spawnPos, rotQ);

        var core = go.GetComponent<ObstacleCore2D>();
        if (core == null) core = go.AddComponent<ObstacleCore2D>();

        core.data = data;
        core.placedCell = cell;
        core.rotation = rotation;

        //����G�� core ���D�ۤv�ݩ���� PlacementSystem�]OnDestroy �|�Ψ��������^
        core.ownerSystem = this;

        foreach (var c in EnumerateFootprint(cell, data.footprintCells))
            occupied[c] = core;

        placed = core;
        return true;
    }


    public bool TryGetAtCell(Vector2Int cell, out ObstacleCore2D core) =>
        occupied.TryGetValue(cell, out core);

    public void Remove(ObstacleCore2D core)
    {
        if (core == null || core.data == null) return;

        Unregister(core);
        Destroy(core.gameObject);
    }

    /// (�i����ܹ��) �����@�}�l�N��{����ê�����U�i����

    public void RegisterExistingObstacles()
    {
        var cores = FindObjectsOfType<ObstacleCore2D>();
        foreach (var core in cores)
        {
            if (core == null || core.data == null) continue;

            // ���s�W�G�w�\��ê�]�n�j�w ownerSystem�AOnDestroy �~��M����
            core.ownerSystem = this;

            // �Y core �S�� placedCell�A�N�Υثe��m��
            if (core.placedCell == default)
                core.placedCell = WorldToCell(core.transform.position);

            foreach (var c in EnumerateFootprint(core.placedCell, core.data.footprintCells))
                occupied[c] = core;
        }
    }

    // �u�M����A�� Destroy�]�� OnDestroy �Ρ^
    public void Unregister(ObstacleCore2D core)
    {
        if (core == null || core.data == null) return;

        foreach (var c in EnumerateFootprint(core.placedCell, core.data.footprintCells))
        {
            if (occupied.TryGetValue(c, out var cur) && cur == core)
                occupied.Remove(c);
        }
    }

}
