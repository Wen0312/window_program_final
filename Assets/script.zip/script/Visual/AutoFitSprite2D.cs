using UnityEngine;

[ExecuteAlways]
[RequireComponent(typeof(SpriteRenderer))]
public class AutoFitSprite2D : MonoBehaviour
{
    // �s�W Stretch�G�|�ܧΡB�w���� targetSize
    public enum FitMode { KeepHeight, KeepWidth, FitInside, FitCover, Stretch }

    [Header("Target size in WORLD units")]
    public Vector2 targetSize = new Vector2(1f, 1f);

    [Header("How to fit the sprite into targetSize")]
    public FitMode fitMode = FitMode.KeepHeight;

    [Header("If true, use sprite bounds (world) and keep localScale clean")]
    public bool applyOnValidate = true;

    SpriteRenderer sr;
    Sprite lastSprite;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    void OnEnable()
    {
        sr = GetComponent<SpriteRenderer>();
        Apply();
    }

    void OnValidate()
    {
        if (!applyOnValidate) return;
        sr = GetComponent<SpriteRenderer>();
        Apply();
    }

    void Update()
    {
#if UNITY_EDITOR
        // �b�s�边���A�� sprite �ɤ]�|�Y�ɮM��
        if (sr != null && sr.sprite != lastSprite) Apply();
#endif
    }

    public void Apply()
    {
        if (sr == null) sr = GetComponent<SpriteRenderer>();
        if (sr.sprite == null) return;

        lastSprite = sr.sprite;

        // sprite ���u�@�ɤؤo�v(bounds.size) �|�� PPU �v�T�A���ڭ̴N�O�n�⥦ fit �� targetSize
        Vector2 spriteWorldSize = sr.sprite.bounds.size;
        if (spriteWorldSize.x <= 0 || spriteWorldSize.y <= 0) return;

        float sx = targetSize.x / spriteWorldSize.x;
        float sy = targetSize.y / spriteWorldSize.y;

        switch (fitMode)
        {
            case FitMode.Stretch:
                // �� �|�ܧΡG�e���U���Y��A�w���� targetSize
                transform.localScale = new Vector3(sx, sy, 1f);
                break;

            case FitMode.KeepHeight:
                // ����G�H���׬���
                transform.localScale = new Vector3(sy, sy, 1f);
                break;

            case FitMode.KeepWidth:
                // ����G�H�e�׬���
                transform.localScale = new Vector3(sx, sx, 1f);
                break;

            case FitMode.FitInside:
                // ����G�����i�h�A�������]�i��d�ťա^
                float sIn = Mathf.Min(sx, sy);
                transform.localScale = new Vector3(sIn, sIn, 1f);
                break;

            case FitMode.FitCover:
                // ����G�л\���]�i������^
                float sCov = Mathf.Max(sx, sy);
                transform.localScale = new Vector3(sCov, sCov, 1f);
                break;

            default:
                // �w�]�G�H���׬���
                transform.localScale = new Vector3(sy, sy, 1f);
                break;
        }
    }
}
